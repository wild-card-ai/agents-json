from .map import map

__all__ = ['map'] 
